# MinhaCasaNovaVida — Simples (inspirado no VivaReal)

Catálogo estático e objetivo, **sem login** e **sem locação**, com **duas categorias**: Casa e Terreno.

## 📦 Conteúdo
- `index.html` — página única com busca, tabs (Casa/Terreno) e cards
- `assets/css/style.css` — estilos minimalistas
- `assets/js/app.js` — dados de exemplo e lógica (filtro + formulário + WhatsApp)

## ⚙️ Configuração rápida
No `index.html`, ajuste no bloco `window.SITE`:
```js
window.SITE = {
  title: "MinhaCasaNovaVida",
  whatsapp: "", // deixe vazio por enquanto; quando tiver use 55DDDNUMERO
  formEndpoint: "" // ex.: https://formspree.io/f/xxxxxx (opcional; vazio = modo demo)
}
```
- Se `whatsapp` estiver vazio, os botões ficam desabilitados automaticamente.
- Se `formEndpoint` estiver vazio, o envio é simulado com sucesso (console).

## 🚀 Publicar no Vercel
1. Suba estes arquivos no seu repositório GitHub.
2. Vercel → **Add New Project** → **Import Git Repository** → **Deploy**.
3. (Opcional) Conecte seu domínio em **Settings → Domains**.

## 🧩 Personalização
Edite `PROPERTIES` em `assets/js/app.js` para colocar seus imóveis reais (fotos, valores, cidade e bairro).
