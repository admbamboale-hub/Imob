
const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

// Apenas VENDA. Categorias: Casa, Terreno.
const PROPERTIES = [
  // Casas (fotos de exemplo via Unsplash; no projeto real, substitua pelos seus URLs)
  {
    id: "CASA-001",
    categoria: "Casa",
    titulo: "Casa térrea moderna com jardim",
    cidade: "Jundiaí",
    bairro: "Vivendas do Japi",
    preco: 1250000,
    area: 210,
    dormitorios: 3,
    banheiros: 3,
    vagas: 2,
    imagens: [
      "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=1600&auto=format&fit=crop"
    ]
  },
  {
    id: "CASA-002",
    categoria: "Casa",
    titulo: "Sobrado alto padrão com vista",
    cidade: "Campo Limpo Paulista",
    bairro: "Portal das Estrelas",
    preco: 1890000,
    area: 280,
    dormitorios: 4,
    banheiros: 5,
    vagas: 3,
    imagens: [
      "https://images.unsplash.com/photo-1600585154084-4e5fe7c39198?q=80&w=1600&auto=format&fit=crop"
    ]
  },
  {
    id: "CASA-003",
    categoria: "Casa",
    titulo: "Casa compacta inteligente",
    cidade: "Jundiaí",
    bairro: "Jardim Itália",
    preco: 640000,
    area: 98,
    dormitorios: 2,
    banheiros: 2,
    vagas: 1,
    imagens: [
      "https://images.unsplash.com/photo-1560185008-b033106af2fb?q=80&w=1600&auto=format&fit=crop"
    ]
  },
  // Terrenos
  {
    id: "TER-001",
    categoria: "Terreno",
    titulo: "Terreno plano em condomínio",
    cidade: "Jundiaí",
    bairro: "Residencial das Colinas",
    preco: 380000,
    area: 360,
    dormitorios: 0,
    banheiros: 0,
    vagas: 0,
    imagens: [
      "https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1600&auto=format&fit=crop"
    ]
  },
  {
    id: "TER-002",
    categoria: "Terreno",
    titulo: "Terreno de esquina com vista livre",
    cidade: "Campo Limpo Paulista",
    bairro: "Bosque das Araucárias",
    preco: 290000,
    area: 300,
    dormitorios: 0,
    banheiros: 0,
    vagas: 0,
    imagens: [
      "https://images.unsplash.com/photo-1460489082367-1bd62d2e0b7b?q=80&w=1600&auto=format&fit=crop"
    ]
  }
];

function badge(text){ return `<span class="badge">${text}</span>`; }

function propertyCard(p){
  return `<article class="property">
    <img class="property__img" src="${p.imagens[0]}" alt="${p.titulo}">
    <div class="property__body">
      <h4>${p.titulo}</h4>
      <div class="price">${BRL.format(p.preco)}</div>
      <div class="badges">
        ${badge(p.categoria)} ${badge(p.cidade)} ${badge(p.bairro)} ${badge(`${p.area} m²`)}
      </div>
    </div>
  </article>`;
}

function renderList(list){
  const wrap = document.getElementById('lista');
  const empty = document.getElementById('vazio');
  wrap.innerHTML = list.map(propertyCard).join('');
  empty.classList.toggle('hidden', list.length !== 0);
}

function filterList(){
  const q = document.getElementById('busca').value.toLowerCase();
  const activeTab = document.querySelector('.tab.active');
  const cat = activeTab ? activeTab.getAttribute('data-categoria') : '';
  let f = PROPERTIES.filter(p => {
    const blob = `${p.titulo} ${p.cidade} ${p.bairro} ${p.categoria}`.toLowerCase();
    const matchQ = !q || blob.includes(q);
    const matchC = !cat || p.categoria === cat;
    return matchQ && matchC;
  });
  renderList(f);
}

function bindUI(){
  document.getElementById('buscarBtn').addEventListener('click', filterList);
  document.getElementById('busca').addEventListener('input', filterList);
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      filterList();
    });
  });
}

function bootWA(){
  const wa = (window.SITE.whatsapp || '').trim();
  const top = document.getElementById('waTop');
  const btn = document.getElementById('waBtn');
  if(wa){
    const msg = encodeURIComponent('Olá! Tenho interesse nos imóveis à venda. Pode me enviar mais detalhes?');
    const link = `https://wa.me/${wa}?text=${msg}`;
    top.href = link; btn.href = link;
    top.classList.remove('disabled'); btn.classList.remove('disabled');
  } else {
    // sem número ainda → mantém desabilitado
  }
}

function handleForm(){
  const form = document.getElementById('leadForm');
  const ok = document.getElementById('okMsg');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    ok.classList.add('hidden');
    const data = new FormData(form);
    try{
      if(window.SITE.formEndpoint){
        await fetch(window.SITE.formEndpoint, { method:'POST', body:data, headers:{Accept:'application/json'} });
      } else {
        await new Promise(r => setTimeout(r, 500)); // demo
        console.log('[DEMO] Lead enviada:', Object.fromEntries(data));
      }
      form.reset();
      ok.classList.remove('hidden');
    }catch(err){
      alert('Não foi possível enviar agora. Tente novamente.');
    }
  });
}

function init(){
  document.getElementById('year').textContent = new Date().getFullYear();
  bindUI();
  bootWA();
  renderList(PROPERTIES);
}
document.addEventListener('DOMContentLoaded', init);
